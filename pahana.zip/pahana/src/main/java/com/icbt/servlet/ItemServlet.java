package com.icbt.servlet;

import com.icbt.model.Item;
import com.icbt.service.ItemService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/ItemServlet")
public class ItemServlet extends HttpServlet {
    private final ItemService itemService = new ItemService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String item_idStr = request.getParameter("item_id");
        String item_name = request.getParameter("item_name");
        String item_description = request.getParameter("item_description");
        String unit_price = request.getParameter("unit_price");
        String stock_quantity = request.getParameter("stock_quantity");

        Item item = new Item();
        item.setItem_name(item_name);
        item.setItem_description(item_description);
        item.setUnit_price(unit_price);
        item.setStock_quantity(stock_quantity);

        boolean success;

        if (item_idStr == null || item_idStr.isEmpty()) {
            // ADD mode
            success = itemService.registerItem(item);
        } else {
            // EDIT mode
            try {
                int item_id = Integer.parseInt(item_idStr);
                item.setItem_id(item_id);
                success = itemService.updateItem(item);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                success = false;
            }
        }

        if (success) {
            response.sendRedirect("ItemServlet");
        } else {
            response.sendRedirect("error.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Handle delete
        String action = request.getParameter("action");
        String idStr = request.getParameter("id");

        if ("delete".equalsIgnoreCase(action) && idStr != null) {
            try {
                int itemId = Integer.parseInt(idStr);
                itemService.deleteItem(itemId);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                response.sendRedirect("error.jsp");
                return;
            }
            response.sendRedirect("ItemServlet");
            return;
        }

        // Otherwise, load list
        List<Item> itemList = itemService.getAllItems();
        request.setAttribute("items", itemList);
        request.getRequestDispatcher("manage-items.jsp").forward(request, response);
    }
}
